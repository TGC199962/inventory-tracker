document.addEventListener('DOMContentLoaded', function () {
    const app = document.getElementById('app');
    app.innerHTML = '<p>Inventory Tracker PWA is ready!</p>';
});
